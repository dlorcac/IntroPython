from functools import reduce

def promedio():
    auto1 = ['Mazda RX4', 21.0, 6, False, 4]
    auto2 = ['Merc 240D', 24.4, 4, True, 2]
    auto3 = ['Merc 280', 19.2, 6, True, 4]
    auto4 = ['Valiant', 18.1, 6, True, 1]
    auto5 = ['Merc 450SL', 17.3, 8, False, 3]
    auto6 = ['Toyota Corolla', 33.9, 4, True, 1]

    anid_list= [auto1,auto2,auto3,auto4,auto5,auto6] 

    anid_list_agrup= [[fila[columna] for fila in anid_list] for columna in range(5)]

    media_col_2= reduce(lambda x,y: x + y, anid_list_agrup[1]) / len(anid_list_agrup[1])
    media_col_3= reduce(lambda x,y: x + y, anid_list_agrup[2]) / len(anid_list_agrup[2])
    media_col_5= reduce(lambda x,y: x + y, anid_list_agrup[4]) / len(anid_list_agrup[4])


    #Hola = list( filter(lambda numero: numero > media_col_2, anid_list[2]) )
    #print (hola)
    nuevalista=[]
    columna2 = [[fila[i] for fila in anid_list] for i in range(5)]
    for i in columna2[1]:
        if i  > media_col_2:
            nuevalista.append(i)

    return nuevalista

print(promedio())
'''    
    print(columna2[1])


    #print(anid_list)
    for f in anid_list:
        #print(f)
        print(f[2])


        
pepe=promedio()
print (pepe)
'''