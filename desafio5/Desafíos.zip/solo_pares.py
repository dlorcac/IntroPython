number = int(input("Ingrese un número\n"))
i = 0
for i in range(i, number, 2):
    if number % 2 == 0:
        print(i)
    else:
        exit()
print(number)