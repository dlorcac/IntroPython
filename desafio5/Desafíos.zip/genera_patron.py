number = int(input("Ingrese un número\n"))
acumulador = ''
for i in range(number + 1):
    for j in range(i):
        num_str = (str(i))
        acumulador += num_str
        acumulador += '\n'
    print(acumulador)