cuenta_regresiva = int(input("Ingrese un número para comenzar la cuenta\n"))
i = 0
while i < cuenta_regresiva:
    print("Iteración {}".format(cuenta_regresiva))
    cuenta_regresiva = cuenta_regresiva-1