import sys

number = int(sys.argv[1])
i=0
string = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis rhoncus malesuada erat, id fringilla quam pellentesque eget. Curabitur vitae leo ut massa ultrices convallis. Nullam varius leo eu porta consectetur. Quisque sagittis nulla sed sapien blandit, posuere dignissim ligula viverra. Morbi a mi at ipsum auctor sollicitudin. Quisque ante erat, maximus sit amet accumsan quis, hendrerit a libero. Maecenas lobortis mauris at ultricies dignissim. Ut finibus risus et congue scelerisque. Vivamus id urna blandit ligula lacinia luctus. Fusce ut dignissim purus. Ut mattis consectetur porttitor. Etiam fermentum et risus sed tincidunt. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos."
while i < number:
    i += 1
    print (string)
    print ('\n')