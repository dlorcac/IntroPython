for i in range(50):
    print("Iteración {}".format(i + 1))